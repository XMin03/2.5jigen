//$(document).ajaxError(function (e, xhr) {
//    console.log(xhr);
//    if (xhr.status == 401)
//        //window.location = "/Account/Login";
//        if (typeof (layoutController !== undefined)) {
//            layoutController.getLoginView();
//        }
//        else if (xhr.status == 403)
//            alert("You have no enough permissions to request this resource.");
//});