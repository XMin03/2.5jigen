/*********************************************************************
*  =Old browsers fallback
*********************************************************************/
if (typeof Array.prototype.forEach !== 'function') {
    Array.prototype.forEach = function (callback, context) {
        for (var i = 0; i < this.length; i++) {
            callback.apply(context, [this[i], i, this]);
        }
    };
}

/*********************************************************************
*  =iPad forEach fallback
*********************************************************************/
function forEach(list, callback) {
    Array.prototype.forEach.call(list, callback)
}


/*********************************************************************
*  =Device verification
*********************************************************************/
var mobileVarification = {
  Android: function () { return navigator.userAgent.match(/Android/i) },
  BlackBerry: function () { return navigator.userAgent.match(/BlackBerry/i) },
  iOS: function () { return navigator.userAgent.match(/iPhone|iPad|iPod/i) },
  iOSNotIpad: function () { return navigator.userAgent.match(/iPhone|iPod/i) },
  Opera: function () { return navigator.userAgent.match(/Opera Mini/i) },
  Windows: function () { return navigator.userAgent.match(/IEMobile/i) || navigator.userAgent.match(/WPDesktop/i) },
  isSmartPhone: function () { return this.Android() || this.BlackBerry() || this.iOSNotIpad() || this.Opera() || this.Windows() },
  any: function () { return this.Android() || this.BlackBerry() || this.iOS() || this.Opera() || this.Windows() }
}

if(!isMobile){
  var isMobile = mobileVarification
}else{
  isMobile = mobileVarification
}

var isSmartPhone = isMobile.isSmartPhone()
var isAMobile = isMobile.any()
var isDesktop = !isMobile.any()
var isIPhone = isMobile.iOS()
var isMac = navigator.platform.match(/(Mac)/i) ? true : false

/**
 * 
 * Check if platform is MAC or IPhone to change support link and visibility hidden for samsung store link 
 */
if(isMac || isIPhone){
  if(document.querySelector("a[href='https://support.bluestacks.com/hc/articles/360021469391-Release-Notes']")){
    document.querySelector("a[href='https://support.bluestacks.com/hc/articles/360021469391-Release-Notes']").setAttribute('href','https://support.bluestacks.com/hc/articles/360024107452');
  }
}else{
  const samsungStoreLink = document.querySelectorAll('.addition-download-wrapper');
  if(samsungStoreLink.length >0){
    samsungStoreLink.forEach(item=>{
      item.classList.remove('hide');
    })
  }
  const headerSamsungLnk = document.querySelector('.samsung-store-lnk');
  if(headerSamsungLnk){
    headerSamsungLnk.classList.add('show');
  }
}

/*********************************************************************
*  =read and delete cookie
*********************************************************************/
function readCookie(name) {
    var pair = document.cookie.match(new RegExp(name + '=([^;]+)'))
    return !!pair ? pair[1] : null
}


var delete_cookie = function(name) {
    document.cookie = name + '=;expires=Thu, 01 Jan 1970 00:00:01 GMT;'
}

// })
