/* ====== || ** cem ** || ====== */
$(".menu-hamburger-btn, .close-nav-bar-menu").click(function () {
    $(".menu ul.nav-bar-menu").toggleClass('active');
    $("body").toggleClass("body-fix");
});
$(".search-btn").click(function () {
    $(".search-boxx").toggleClass("active");
});
$("li.nav-bar-user-menu").click(function () {
    $("li.nav-bar-user-menu").toggleClass("selected");
});
$(".close-nav-bar-menu").click(function () {
    $("ul.nav-bar-menu li").removeClass("selected");
});
var selector = '.menu ul.nav-bar-menu li';
$(selector).on('click', function () {
    if ($(this).hasClass('selected'))
        $(this).removeClass('selected');
    else
        $(this).addClass('selected');
});

$('.novels-detail-chapters-btn-list .novels-detail-chapters-btn').click(function ()
{
    var tab_id = $(this).attr('data-tab');
    $(".novels-detail-chapters-btn").removeClass('active');
    $(".cm-tabs-content").removeClass('active');
    $(this).addClass('active');
    $('#' + tab_id).addClass('active');
});

var selector = '.menu ul.nav-bar-items li.notification';
$(selector).on('click', function () {
    if ($(this).hasClass('selected'))
        $(this).removeClass('selected');
    else
        $(this).addClass('selected');
});
$('.back-to-top').click(function () {
    $(window.opera ? 'html' : 'html, body').animate({
        scrollTop: 0
    });
});
var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
    return new bootstrap.Tooltip(tooltipTriggerEl)
});
$(".close-warnings").on('click', function () {
    $(this).parent('.warnings').removeClass("none");
    $(this).parent('.warnings').addClass("none");
});


'use strict';
;(function (document, window, index) {
    var inputs = document.querySelectorAll('.inputfile');
    Array.prototype.forEach.call(inputs, function (input) {
        var label = input.nextElementSibling,
            labelVal = label.innerHTML;

        input.addEventListener('change', function (e) {
            var fileName = '';
            if (this.files && this.files.length > 1)
                fileName = (this.getAttribute('data-multiple-caption') || '').replace('{count}', this.files.length);
            else
                fileName = e.target.value.split('\\').pop();

            if (fileName)
                label.querySelector('span').innerHTML = fileName;
            else
                label.innerHTML = labelVal;
        });

        // Firefox bug fix
        input.addEventListener('focus', function () {
            input.classList.add('has-focus');
        });
        input.addEventListener('blur', function () {
            input.classList.remove('has-focus');
        });
    });
}(document, window, 0));

/********************************************************************/
/* ====== || ** tasarım ekranında görüntülenebilmesi için yazdım, eğer yazılımcı arkadaş için uygun değilse değiştirebilir ** || ====== */
/*****/
/*****/


$(".search-boxx-input").keyup(function () {
    tmpval = $(this).val();
    if (tmpval != '' && tmpval.length > 0) {
        $(".search-result").removeClass('d-none');
    } else {
        $(".search-result").addClass('d-none');
    }
});

$( document ).ready(function() {
    var selector = ".appearance .appearance-view";
    $(selector).on('click', function(){
        $(selector).removeClass('active');
        $(this).addClass('active');
    });
});

$(".section-header-button").click(function () {
    $(".crate-discussion").toggleClass("active");
});

$(".appearance .appearance-view.grid-view").on('click', function () {
    $(".category-items").removeClass("cm-list cm-grid");
    $(".category-items").addClass("cm-grid");
    writeCookie('change_view','grid',30); 
   // alert('grid');
 
});
$(".appearance .appearance-view.list-view").on('click', function () {
    $(".category-items").removeClass("cm-list cm-grid");
    $(".category-items").addClass("cm-list");
    writeCookie('change_view','list',30);
    //alert('list');
 
});
var selector = '.discussion-detail-emoji-drop > span';
$(".discussion-detail-emoji-drop").on('click', function () {
    if ($(".discussion-detail-emoji-drop").hasClass('active'))
        $(".discussion-detail-emoji-drop").removeClass('active');
    else
        $(this).addClass('active');
});
$(".discussion-comment-reply").on('click', function () {
    $('.comment-replying').removeClass('active');
    $(this).parent('.search-discussion-user-name').parent('.search-discussion-top').siblings('.comment-replying').addClass('active');
});

/*****/
/*****/
/********************************************************************/

/*==================================================== cookie ====================================================*/

function writeCookie(name, value, days) {
    if(days==null || days=="")days=365;
    var d=new Date();
    d.setTime(d.getTime()+(days*24*60*60*1000));
    var expires="; expires="+d.toGMTString();
    document.cookie = name+"="+value+expires+";domain=.lightnovelreader.org; path=/";
}
function readCookie(name){
    var c=document.cookie ;
    if (c.indexOf(name)!=-1) {
        pos1=c.indexOf("=", c.indexOf(name))+1;
        pos2=c.indexOf(";",pos1);
        if(pos2==-1)    pos2=c.length;;
        data=c.substring(pos1,pos2);
        return data;
    }
}

$( document ).ready(function() {
    if(readCookie('darkTemplate') === undefined)
        writeCookie('darkTemplate', false, 365);
    changeTheme();
}); 
function setCssPropertyColor(key, value){document.documentElement.style.setProperty('--' + key, value);}

function toggleTheme()
{
    var cookie_value = readCookie('darkTemplate');
    writeCookie('darkTemplate', !(cookie_value === 'true'), 365);
    changeTheme();
}

function changeTheme()
{
    if(readCookie('darkTemplate') != 'true') //light
    {
        setCssPropertyColor('pbl-base-color-1', '#2563eb');
        setCssPropertyColor('pbl-base-color-1-1', '#1d4ed8');
        setCssPropertyColor('pbl-base-color-2', '#c0392b');
        setCssPropertyColor('pbl-base-color-2-1', '#ab1000');
        setCssPropertyColor('pbl-base-color-3', '#ea580c');
        setCssPropertyColor('pbl-base-color-3-1', '#c2410c');
        setCssPropertyColor('pbl-base-color-4', '#eab308');
        setCssPropertyColor('pbl-base-color-4-1', '#cf9e06');
        setCssPropertyColor('pbl-base-color-5', '#119f00');
        setCssPropertyColor('pbl-base-color-5-1', '#0d7600');
        setCssPropertyColor('pbl-color-1', '#000000');
        setCssPropertyColor('pbl-color-2', '#ffffff');
        setCssPropertyColor('pbl-color-3', '#f1f5f9');
        setCssPropertyColor('pbl-color-4', '#F8FAFC');
        setCssPropertyColor('pbl-color-5', '#e2e8f0');
        setCssPropertyColor('pbl-color-6', '#dbeafe');
        setCssPropertyColor('pbl-color-7', '#64748b');
        setCssPropertyColor('pbl-color-8', '#475569');
        setCssPropertyColor('pbl-color-9', '#0f172a');
        setCssPropertyColor('pbl-color-black', '#000000');
        setCssPropertyColor('pbl-color-white', '#ffffff');
        setCssPropertyColor('pbl-body-color', '#ffffff');
        setCssPropertyColor('pbl-drk-padding-15', '0px');
        $('.site-logo').attr('src','/assets/new/images/logo.png');
    }
    else // dark
    {
        setCssPropertyColor('pbl-base-color-1', '#2563eb');
        setCssPropertyColor('pbl-base-color-1-1', '#1d4ed8');
        setCssPropertyColor('pbl-base-color-2', '#c0392b');
        setCssPropertyColor('pbl-base-color-2-1', '#ab1000');
        setCssPropertyColor('pbl-base-color-3', '#ea580c');
        setCssPropertyColor('pbl-base-color-3-1', '#c2410c');
        setCssPropertyColor('pbl-base-color-4', '#eab308');
        setCssPropertyColor('pbl-base-color-4-1', '#cf9e06');
        setCssPropertyColor('pbl-base-color-5', '#119f00');
        setCssPropertyColor('pbl-base-color-5-1', '#0d7600');
        setCssPropertyColor('pbl-color-1', '#b9b9b9');
        setCssPropertyColor('pbl-color-2', '#181818');
        setCssPropertyColor('pbl-color-3', '#202020');
        setCssPropertyColor('pbl-color-4', '#141414');
        setCssPropertyColor('pbl-color-5', '#2e2e2e');
        setCssPropertyColor('pbl-color-6', '#334154');
        setCssPropertyColor('pbl-color-7', '#64748b');
        setCssPropertyColor('pbl-color-8', '#79879d');
        setCssPropertyColor('pbl-color-9', '#0f172a');
        setCssPropertyColor('pbl-color-black', '#000000');
        setCssPropertyColor('pbl-color-white', '#ffffff');
        setCssPropertyColor('pbl-body-color', '#313131');
        setCssPropertyColor('pbl-drk-padding-15', '15px');

        $('.site-logo').attr('src','/assets/new/images/logodarknew.png');
    }
}